package com.kiranacademy.Restapex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapexApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapexApplication.class, args);
	}

}
