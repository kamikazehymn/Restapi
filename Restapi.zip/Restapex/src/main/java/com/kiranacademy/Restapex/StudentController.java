package com.kiranacademy.Restapex;




import java.util.ArrayList;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:8080")
public class StudentController {
	
	ArrayList<Student> arrayList=new ArrayList<Student>();
	
	StudentController()
	{
		Student student1=new Student(1,90);
		Student student2=new Student(2,80);
		
		arrayList.add(student1);
		arrayList.add(student2);
	}
		
	@GetMapping("students")
	ArrayList<Student> allStudents()
	{
		return arrayList;
	}

	// @PathVariable assign value of path variable to local variable
	// localhost:8080/student/1
	@GetMapping("student/{rno}")
	public Student getStudent(@PathVariable int rno)
	{
			
		for (Student student : arrayList) 
		{
			if(student.rno==rno)
				return student;
				
		}
		
		return null;
	}
	
	@PostMapping("student")
	public ArrayList<Student>  addStudent(@RequestBody Student student)
	{
		arrayList.add(student);
		return arrayList;
	}
	
	
	@DeleteMapping("student/{rno}")
	public String deleteStudent(@PathVariable int rno)
	{
		
		Student deleteStudent=null;
		
		
		for (Student student : arrayList) 
		{
			if(student.rno==rno)
			{
				deleteStudent=student;
		
				// concurrentModification exception may occur if we use ArrayList's remove here .
			}
				
		}
				
		arrayList.remove(deleteStudent);
				
		return "record deleted";
	}
	
	//{"rno"2,"marks":35} , using this JSON String , @RequestBody will create Student object clientStudent.
	
	// for updation , use @PutMapping
	@PutMapping("student")
	public ArrayList<Student> updateStudent(@RequestBody Student clientStudent)
	{
		
			Student updateStudent=null;
			
			for(Student student : arrayList) 
			{
				if(student.rno==clientStudent.rno)
				{
					updateStudent=student;
					
				}
			}
			
			
			updateStudent.setMarks(clientStudent.getMarks());
	
			return arrayList;
	
	}
	
}

	


