package com.kiranacademy.Restapex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapexApplicationTests {

	@Test
	void contextLoads() {
	}

}
